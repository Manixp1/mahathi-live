import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // Track active rooms and their participants
  // Key: roomId, Value: { parentId, childId }
  const activeRooms = new Map<string, { parentId?: string; childId?: string }>();
  // Track socket to room mapping for cleanup
  const socketInfo = new Map<string, { roomId: string; role: string }>();

  // Socket.io Logic
  io.on("connection", (socket) => {
    console.log(`User connected: ${socket.id}`);

    socket.on("join-room", ({ roomId, role }) => {
      socket.join(roomId);
      console.log(`User ${socket.id} joined room ${roomId} as ${role}`);
      
      // Update room tracking
      const room = activeRooms.get(roomId) || {};
      if (role === "parent") {
        room.parentId = socket.id;
      } else if (role === "child") {
        room.childId = socket.id;
      }
      activeRooms.set(roomId, room);
      socketInfo.set(socket.id, { roomId, role });

      // Notify others in the room
      socket.to(roomId).emit("user-joined", { userId: socket.id, role });
    });

    // WebRTC Signaling
    socket.on("signal", ({ roomId, data }) => {
      socket.to(roomId).emit("signal", { from: socket.id, data });
    });

    // Real-time Location Relay
    socket.on("location-update", ({ roomId, location }) => {
      socket.to(roomId).emit("location-update", { from: socket.id, location });
    });

    socket.on("disconnect", () => {
      const info = socketInfo.get(socket.id);
      if (info) {
        const { roomId, role } = info;
        console.log(`User ${socket.id} (${role}) disconnected from room ${roomId}`);
        
        // Notify others about the disconnection
        socket.to(roomId).emit("user-disconnected", { userId: socket.id, role });

        // Cleanup room state
        const room = activeRooms.get(roomId);
        if (room) {
          if (role === "parent") {
            delete room.parentId;
          } else if (role === "child") {
            delete room.childId;
          }

          if (!room.parentId && !room.childId) {
            activeRooms.delete(roomId);
            console.log(`Room ${roomId} cleaned up (empty)`);
          } else {
            activeRooms.set(roomId, room);
          }
        }
        socketInfo.delete(socket.id);
      }
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      const indexPath = path.resolve(distPath, "index.html");
      res.sendFile(indexPath);
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Signaling Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
