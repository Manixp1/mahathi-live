// Parent App: main.dart
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';

void main() => runApp(MaterialApp(home: ParentApp()));

class ParentApp extends StatefulWidget {
  @override
  _ParentAppState createState() => _ParentAppState();
}

class _ParentAppState extends State<ParentApp> {
  String roomId = "";
  late IO.Socket socket;
  RTCPeerConnection? _peerConnection;
  RTCVideoRenderer _remoteRenderer = RTCVideoRenderer();
  RTCVideoRenderer _remoteScreenRenderer = RTCVideoRenderer();
  
  LatLng _childLocation = LatLng(0, 0);
  LatLng? _alertLocation;
  Set<Marker> _markers = {};
  GoogleMapController? _mapController;

  bool _isAudioMuted = false;
  bool _isVideoOff = false;
  bool _isChildConnected = false;
  String _iceConnectionState = 'Disconnected';
  String _childActivityStatus = 'active';
  int? _childBatteryLevel;

  @override
  void initState() {
    super.initState();
    _loadRoomId();
    _updateMarkers();
    _initRenderers();
  }

  Future<void> _loadRoomId() async {
    final prefs = await SharedPreferences.getInstance();
    String? storedId = prefs.getString('parent_room_id');
    
    if (storedId != null) {
      setState(() => roomId = storedId);
    } else {
      String newId = _generateRoomId();
      await prefs.setString('parent_room_id', newId);
      setState(() => roomId = newId);
    }
    
    _connectSocket();
  }

  String _generateRoomId() {
    return Random().nextInt(999999).toString().padLeft(6, '0');
  }

  Future<void> _initRenderers() async {
    await _remoteRenderer.initialize();
    await _remoteScreenRenderer.initialize();
  }

  void _connectSocket() {
    if (roomId.isEmpty) return;
    
    // REPLACE WITH YOUR SERVER URL
    socket = IO.io('https://ais-dev-cdo773dxmuqcudwxpzqpvj-157975582685.asia-southeast1.run.app', 
      IO.OptionBuilder()
        .setTransports(['websocket'])
        .enableAutoConnect()
        .setReconnectionAttempts(10)
        .setReconnectionDelay(5000)
        .build());

    socket.onConnect((_) {
      print('Connected to server');
      socket.emit('join-room', {'roomId': roomId, 'role': 'parent'});
    });

    socket.onReconnect((_) {
      print('Reconnected to server');
      socket.emit('join-room', {'roomId': roomId, 'role': 'parent'});
    });

    socket.on('signal', (data) async {
      var signalData = data['data'];
      if (signalData['type'] == 'offer') {
        await _handleOffer(signalData);
      } else if (signalData['type'] == 'candidate') {
        await _peerConnection?.addCandidate(
          RTCIceCandidate(signalData['candidate'], signalData['sdpMid'], signalData['sdpMLineIndex'])
        );
      }
    });

    socket.on('location-update', (data) {
      setState(() {
        _childLocation = LatLng(data['location']['lat'], data['location']['lng']);
        _updateMarkers();
        _mapController?.animateCamera(CameraUpdate.newLatLng(_childLocation));
      });
    });

    socket.on('activity-status', (data) {
      setState(() {
        _childActivityStatus = data['status'];
      });
      if (_childActivityStatus == 'inactive') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Child has been inactive for a while."),
            backgroundColor: Colors.orange,
          ),
        );
      }
    });

    socket.on('battery-update', (data) {
      setState(() {
        _childBatteryLevel = data['battery'];
      });
    });

    socket.on('user-joined', (data) {
      if (data['role'] == 'child') {
        setState(() => _isChildConnected = true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Child joined the room!"), backgroundColor: Colors.green),
        );
      }
    });

    socket.on('user-disconnected', (data) {
      if (data['role'] == 'child') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Child disconnected unexpectedly!"), backgroundColor: Colors.red),
        );
        setState(() {
          _isChildConnected = false;
          _iceConnectionState = 'Disconnected';
          _remoteRenderer.srcObject = null;
          _remoteScreenRenderer.srcObject = null;
          _alertLocation = null;
          _updateMarkers();
        });
      }
    });
  }

  void _updateMarkers() {
    setState(() {
      _markers = {
        Marker(
          markerId: MarkerId("child"),
          position: _childLocation,
          infoWindow: InfoWindow(title: "Child's Location"),
        ),
      };
      if (_alertLocation != null) {
        _markers.add(
          Marker(
            markerId: MarkerId("alert"),
            position: _alertLocation!,
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
            infoWindow: InfoWindow(title: "Manual Alert Area"),
          ),
        );
      }
    });
  }

  void _onMapTap(LatLng position) {
    setState(() {
      _alertLocation = position;
      _updateMarkers();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Alert set at: ${position.latitude.toStringAsFixed(4)}, ${position.longitude.toStringAsFixed(4)}"),
        duration: Duration(seconds: 3),
        action: SnackBarAction(
          label: "Clear",
          onPressed: () {
            setState(() {
              _alertLocation = null;
              _updateMarkers();
            });
          },
        ),
      ),
    );
  }

  Future<void> _handleOffer(dynamic offer) async {
    _peerConnection = await createPeerConnection({
      'iceServers': [{'urls': 'stun:stun.l.google.com:19302'}]
    });

    _peerConnection!.onIceConnectionState = (state) {
      setState(() {
        _iceConnectionState = state.toString().split('.').last;
      });
    };

    _peerConnection!.onIceCandidate = (candidate) {
      socket.emit('signal', {
        'roomId': roomId,
        'data': {
          'type': 'candidate',
          'candidate': candidate.candidate,
          'sdpMid': candidate.sdpMid,
          'sdpMLineIndex': candidate.sdpMLineIndex
        }
      });
    };

    _peerConnection!.onTrack = (event) {
      if (event.track.kind == 'video') {
        setState(() {
          // If camera renderer is empty, use it. Otherwise use screen renderer.
          if (_remoteRenderer.srcObject == null) {
            _remoteRenderer.srcObject = event.streams[0];
            _remoteRenderer.srcObject?.getAudioTracks().forEach((track) => track.enabled = !_isAudioMuted);
            _remoteRenderer.srcObject?.getVideoTracks().forEach((track) => track.enabled = !_isVideoOff);
          } else {
            _remoteScreenRenderer.srcObject = event.streams[0];
          }
        });
      }
    };

    await _peerConnection!.setRemoteDescription(RTCSessionDescription(offer['sdp'], offer['type']));
    RTCSessionDescription answer = await _peerConnection!.createAnswer();
    await _peerConnection!.setLocalDescription(answer);

    socket.emit('signal', {
      'roomId': roomId,
      'data': {'type': 'answer', 'sdp': answer.sdp}
    });
  }

  void _toggleAudio() {
    setState(() {
      _isAudioMuted = !_isAudioMuted;
      _remoteRenderer.srcObject?.getAudioTracks().forEach((track) {
        track.enabled = !_isAudioMuted;
      });
    });
  }

  void _toggleVideo() {
    setState(() {
      _isVideoOff = !_isVideoOff;
      _remoteRenderer.srcObject?.getVideoTracks().forEach((track) {
        track.enabled = !_isVideoOff;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (roomId.isEmpty) {
      return Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    
    return Scaffold(
      appBar: AppBar(
        title: Text("Mahathi Live - Room: $roomId"),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                Icon(
                  Icons.child_care,
                  color: _isChildConnected ? Colors.green : Colors.grey,
                  size: 20,
                ),
                SizedBox(width: 4),
                Text(
                  _isChildConnected ? "1 Child" : "0 Child",
                  style: TextStyle(fontSize: 12),
                ),
                if (_isChildConnected) ...[
                  SizedBox(width: 8),
                  Icon(
                    _childActivityStatus == 'active' ? Icons.directions_run : Icons.bedtime,
                    color: _childActivityStatus == 'active' ? Colors.blue : Colors.orange,
                    size: 16,
                  ),
                  if (_childBatteryLevel != null) ...[
                    SizedBox(width: 8),
                    Icon(
                      _childBatteryLevel! > 20 ? Icons.battery_full : Icons.battery_alert,
                      color: _childBatteryLevel! > 20 ? Colors.green : Colors.red,
                      size: 16,
                    ),
                    SizedBox(width: 4),
                    Text(
                      "$_childBatteryLevel%",
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ],
                ],
                SizedBox(width: 16),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _iceConnectionState == 'connected' ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "P2P: $_iceConnectionState",
                    style: TextStyle(
                      fontSize: 10,
                      color: _iceConnectionState == 'connected' ? Colors.green : Colors.redAccent,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Center(
              child: QrImageView(data: roomId, size: 200),
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      // Camera Stream
                      Expanded(
                        child: Stack(
                          children: [
                            RTCVideoView(_remoteRenderer),
                            if (_childActivityStatus == 'inactive')
                              Container(
                                color: Colors.black.withOpacity(0.7),
                                child: Center(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.bedtime, color: Colors.orange, size: 40),
                                      SizedBox(height: 8),
                                      Text("Child Inactive", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                      Text("Stream Paused", style: TextStyle(color: Colors.white70, fontSize: 10)),
                                    ],
                                  ),
                                ),
                              ),
                            Positioned(
                              top: 5,
                              left: 5,
                              child: Container(
                                padding: EdgeInsets.all(4),
                                color: Colors.black54,
                                child: Text("Camera", style: TextStyle(color: Colors.white, fontSize: 10)),
                              ),
                            ),
                            Positioned(
                              bottom: 10,
                              left: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.black54,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  children: [
                                    IconButton(
                                      icon: Icon(_isAudioMuted ? Icons.volume_off : Icons.volume_up, color: Colors.white),
                                      onPressed: _toggleAudio,
                                    ),
                                    IconButton(
                                      icon: Icon(_isVideoOff ? Icons.videocam_off : Icons.videocam, color: Colors.white),
                                      onPressed: _toggleVideo,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Screen Share Stream
                      Expanded(
                        child: Stack(
                          children: [
                            RTCVideoView(_remoteScreenRenderer),
                            if (_childActivityStatus == 'inactive')
                              Container(
                                color: Colors.black.withOpacity(0.7),
                                child: Center(
                                  child: Icon(Icons.bedtime, color: Colors.orange.withOpacity(0.5), size: 30),
                                ),
                              ),
                            Positioned(
                              top: 5,
                              left: 5,
                              child: Container(
                                padding: EdgeInsets.all(4),
                                color: Colors.black54,
                                child: Text("Screen", style: TextStyle(color: Colors.white, fontSize: 10)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(target: _childLocation, zoom: 15),
                    onMapCreated: (controller) => _mapController = controller,
                    markers: _markers,
                    zoomGesturesEnabled: true,
                    scrollGesturesEnabled: true,
                    tiltGesturesEnabled: true,
                    rotateGesturesEnabled: true,
                    onTap: _onMapTap,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _remoteRenderer.dispose();
    _remoteScreenRenderer.dispose();
    _peerConnection?.dispose();
    socket.dispose();
    super.dispose();
  }
}
