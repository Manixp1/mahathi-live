import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { Shield, Activity, MapPin, Video, Monitor } from 'lucide-react';

export default function App() {
  const [status, setStatus] = useState('Disconnected');
  const [roomCount, setRoomCount] = useState(0);

  useEffect(() => {
    const socket = io();
    socket.on('connect', () => setStatus('Connected'));
    socket.on('disconnect', () => setStatus('Disconnected'));
    
    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans p-8">
      <header className="max-w-4xl mx-auto mb-12 flex items-center justify-between border-b border-zinc-800 pb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-zinc-900 rounded-xl overflow-hidden border border-zinc-800 flex items-center justify-center">
            <img 
              src="https://lh3.googleusercontent.com/d/1ORwAAmk7iMQzlueAh5SPQLyxMQL0KYnB" 
              alt="Mahathi Live Logo" 
              className="w-full h-full object-contain p-1"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "https://picsum.photos/seed/mahathi/200/200";
              }}
            />
          </div>
          <h1 className="text-2xl font-bold tracking-tight uppercase">Mahathi Live <span className="text-zinc-500 font-light italic">Signaling</span></h1>
        </div>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${status === 'Connected' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
          <span className="text-xs uppercase tracking-widest font-semibold opacity-70">{status}</span>
        </div>
      </header>

      <main className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
          <div className="flex items-center gap-3 mb-4">
            <Activity className="w-5 h-5 text-orange-400" />
            <h2 className="text-sm uppercase tracking-widest font-bold">Server Status</h2>
          </div>
          <p className="text-zinc-400 text-sm leading-relaxed mb-6">
            The signaling server is active and listening for WebRTC connections. This server acts as the bridge between the Parent and Child apps.
          </p>
          <div className="space-y-3">
            <div className="flex justify-between text-xs border-b border-zinc-800 pb-2">
              <span className="text-zinc-500">Port</span>
              <span className="font-mono">3000</span>
            </div>
            <div className="flex justify-between text-xs border-b border-zinc-800 pb-2">
              <span className="text-zinc-500">Protocol</span>
              <span className="font-mono">Socket.io / WebRTC</span>
            </div>
          </div>
        </section>

        <section className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
          <div className="flex items-center gap-3 mb-4">
            <Monitor className="w-5 h-5 text-orange-400" />
            <h2 className="text-sm uppercase tracking-widest font-bold">Capabilities</h2>
          </div>
          <ul className="space-y-4">
            <li className="flex items-center gap-3 text-xs">
              <Video className="w-4 h-4 text-zinc-500" />
              <span>Real-time P2P Video/Audio Streaming</span>
            </li>
            <li className="flex items-center gap-3 text-xs">
              <Monitor className="w-4 h-4 text-zinc-500" />
              <span>Live Screen Mirroring</span>
            </li>
            <li className="flex items-center gap-3 text-xs">
              <MapPin className="w-4 h-4 text-zinc-500" />
              <span>GPS Location Relay (5-10s updates)</span>
            </li>
          </ul>
        </section>

        <section className="md:col-span-2 bg-orange-500/10 border border-orange-500/20 p-6 rounded-2xl">
          <h3 className="text-orange-500 text-sm font-bold uppercase mb-2">Developer Instructions</h3>
          <p className="text-zinc-300 text-xs leading-relaxed">
            The Flutter code for the Parent and Child apps has been generated in the project root. 
            Check <code className="bg-zinc-950 px-1 py-0.5 rounded">flutter_instructions.txt</code> for setup details.
            Ensure you update the server URL in the Flutter apps to match this environment's URL.
          </p>
        </section>
      </main>

      <footer className="max-w-4xl mx-auto mt-12 pt-6 border-t border-zinc-800 text-[10px] uppercase tracking-widest text-zinc-600 flex justify-between">
        <span>No Data Stored • Strictly Real-time</span>
        <span>v1.0.0-alpha</span>
      </footer>
    </div>
  );
}
