// Child App: main.dart
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'dart:async';
import 'dart:math' as math;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeService();
  runApp(MaterialApp(home: ChildApp()));
}

Future<void> initializeService() async {
  final service = FlutterBackgroundService();
  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      autoStart: false,
      isForegroundMode: true,
      notificationChannelId: 'my_foreground',
      initialNotificationTitle: 'Monitoring Active',
      initialNotificationContent: 'Streaming location and media...',
      foregroundServiceNotificationId: 888,
    ),
    iosConfiguration: IosConfiguration(),
  );
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  // This runs in a separate isolate
  print("Foreground Service: Starting...");

  if (service is AndroidServiceInstance) {
    service.on('setAsForeground').listen((event) {
      service.setAsForegroundService();
    });

    service.on('setAsBackground').listen((event) {
      service.setAsBackgroundService();
    });
  }

  service.on('stopService').listen((event) {
    service.stopSelf();
    print("Foreground Service: Stopped by user");
  });

  IO.Socket socket = IO.io('https://ais-dev-cdo773dxmuqcudwxpzqpvj-157975582685.asia-southeast1.run.app', 
    IO.OptionBuilder()
      .setTransports(['websocket'])
      .enableAutoConnect()
      .setReconnectionAttempts(10)
      .setReconnectionDelay(5000)
      .build());

  String? currentRoomId;
  bool isStreaming = false;
  DateTime lastActivity = DateTime.now();
  const Duration inactivityThreshold = Duration(minutes: 5);
  bool isInactive = false;
  final Battery battery = Battery();

  void updateNotification(String status) {
    if (service is AndroidServiceInstance) {
      service.setForegroundNotificationInfo(
        title: "Monitoring: $status",
        content: currentRoomId != null ? "Room: $currentRoomId" : "Waiting for pairing...",
      );
    }
  }

  socket.onConnect((_) {
    print("Foreground Service: Socket connected");
    if (currentRoomId != null) {
      socket.emit('join-room', {'roomId': currentRoomId, 'role': 'child'});
      updateNotification("Streaming Active");
    } else {
      updateNotification("Idle");
    }
  });

  socket.onDisconnect((_) {
    print("Foreground Service: Socket disconnected");
    updateNotification("Disconnected (Reconnecting...)");
  });

  socket.onReconnect((_) {
    print("Foreground Service: Socket reconnected");
    if (currentRoomId != null) {
      socket.emit('join-room', {'roomId': currentRoomId, 'role': 'child'});
      updateNotification("Streaming Active");
    }
  });

  service.on('setRoomId').listen((event) {
    currentRoomId = event?['roomId'];
    print("Foreground Service: Room ID set to $currentRoomId");
    socket.emit('join-room', {'roomId': currentRoomId, 'role': 'child'});
    updateNotification("Streaming Active");
    lastActivity = DateTime.now();
    isInactive = false;
  });

  service.on('user-activity').listen((event) {
    lastActivity = DateTime.now();
    if (isInactive) {
      isInactive = false;
      print("Foreground Service: User activity detected, resuming...");
      socket.emit('activity-status', {'roomId': currentRoomId, 'status': 'active'});
      service.invoke('on-activity');
      updateNotification("Streaming Active");
    }
  });

  // Physical movement detection
  accelerometerEvents.listen((AccelerometerEvent event) {
    double acceleration = math.sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
    // Gravity is ~9.8, so anything significantly different means movement
    if ((acceleration - 9.8).abs() > 0.5) {
      lastActivity = DateTime.now();
      if (isInactive) {
        isInactive = false;
        print("Foreground Service: Physical movement detected, resuming...");
        socket.emit('activity-status', {'roomId': currentRoomId, 'status': 'active'});
        service.invoke('on-activity');
        updateNotification("Streaming Active");
      }
    }
  });

  // Periodic status check and location update
  Timer.periodic(Duration(seconds: 10), (timer) async {
    if (currentRoomId != null) {
      try {
        // Check for inactivity
        if (DateTime.now().difference(lastActivity) > inactivityThreshold && !isInactive) {
          isInactive = true;
          print("Foreground Service: Inactivity detected, notifying parent...");
          socket.emit('activity-status', {'roomId': currentRoomId, 'status': 'inactive'});
          service.invoke('on-inactivity');
          updateNotification("Idle (Inactivity Detected)");
        }

        if (!socket.connected) {
          print("Foreground Service: Socket not connected, attempting manual connect...");
          socket.connect();
        }

        Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 5),
        );
        
        socket.emit('location-update', {
          'roomId': currentRoomId,
          'location': {'lat': position.latitude, 'lng': position.longitude}
        });
        print("Foreground Service: Location updated (${position.latitude}, ${position.longitude})");

        // Battery update
        int batteryLevel = await battery.batteryLevel;
        socket.emit('battery-update', {
          'roomId': currentRoomId,
          'battery': batteryLevel
        });
        print("Foreground Service: Battery updated ($batteryLevel%)");
      } catch (e) {
        print("Foreground Service Error: $e");
      }
    }
  });
}

class ChildApp extends StatefulWidget {
  @override
  _ChildAppState createState() => _ChildAppState();
}

class _ChildAppState extends State<ChildApp> {
  String? roomId;
  late IO.Socket socket;
  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;

  // Quality Settings
  String _selectedResolution = '720p';
  int _selectedFPS = 30;
  int _selectedBitrate = 2000; // kbps

  final Map<String, Map<String, int>> _resolutions = {
    '480p': {'width': 640, 'height': 480},
    '720p': {'width': 1280, 'height': 720},
    '1080p': {'width': 1920, 'height': 1080},
  };

  @override
  void initState() {
    super.initState();
    _connectSocket();
    _setupServiceListeners();
  }

  void _setupServiceListeners() {
    FlutterBackgroundService().on('on-inactivity').listen((event) {
      print("UI: Inactivity detected, pausing stream...");
      _localStream?.getTracks().forEach((track) => track.enabled = false);
    });

    FlutterBackgroundService().on('on-activity').listen((event) {
      print("UI: Activity detected, resuming stream...");
      _localStream?.getTracks().forEach((track) => track.enabled = true);
    });
  }

  void _connectSocket() {
    socket = IO.io('https://ais-dev-cdo773dxmuqcudwxpzqpvj-157975582685.asia-southeast1.run.app', 
      IO.OptionBuilder()
        .setTransports(['websocket'])
        .enableAutoConnect()
        .setReconnectionAttempts(10)
        .setReconnectionDelay(5000)
        .build());

    socket.onConnect((_) {
      if (roomId != null) {
        socket.emit('join-room', {'roomId': roomId, 'role': 'child'});
      }
    });

    socket.onReconnect((_) {
      if (roomId != null) {
        socket.emit('join-room', {'roomId': roomId, 'role': 'child'});
      }
    });

    socket.on('user-disconnected', (data) {
      if (data['role'] == 'parent') {
        _peerConnection?.close();
        _peerConnection = null;
        setState(() {
          roomId = null;
        });
        FlutterBackgroundService().stopService();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Parent disconnected. Monitoring stopped.")),
        );
      }
    });
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.camera,
      Permission.microphone,
      Permission.location,
      Permission.notification,
    ].request();
  }

  Future<void> _startStreaming(String id) async {
    await _requestPermissions();
    setState(() => roomId = id);
    socket.emit('join-room', {'roomId': roomId, 'role': 'child'});
    FlutterBackgroundService().invoke('setRoomId', {'roomId': roomId});
    FlutterBackgroundService().startService();
    FlutterBackgroundService().invoke('setAsForeground');

    // WebRTC Setup
    _peerConnection = await createPeerConnection({
      'iceServers': [{'urls': 'stun:stun.l.google.com:19302'}]
    });

    _peerConnection!.onIceCandidate = (candidate) {
      socket.emit('signal', {
        'roomId': roomId,
        'data': {
          'type': 'candidate',
          'candidate': candidate.candidate,
          'sdpMid': candidate.sdpMid,
          'sdpMLineIndex': candidate.sdpMLineIndex
        }
      });
    };

    _localStream = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': {
        'facingMode': 'user',
        'width': _resolutions[_selectedResolution]!['width'],
        'height': _resolutions[_selectedResolution]!['height'],
        'frameRate': _selectedFPS,
      }
    });

    _localStream!.getTracks().forEach((track) {
      _peerConnection!.addTrack(track, _localStream!);
    });

    // Add Screen Share
    try {
      // Request screen capture permission explicitly for Android
      await Helper.requestScreenCapturePermission();
      
      MediaStream screenStream = await navigator.mediaDevices.getDisplayMedia({
        'video': {
          'width': _resolutions[_selectedResolution]!['width'],
          'height': _resolutions[_selectedResolution]!['height'],
          'frameRate': _selectedFPS,
        },
        'audio': false,
      });
      screenStream.getTracks().forEach((track) {
        _peerConnection!.addTrack(track, screenStream);
      });
    } catch (e) {
      print("Screen share failed or cancelled: $e");
    }

    RTCSessionDescription offer = await _peerConnection!.createOffer({
      'offerToReceiveAudio': false,
      'offerToReceiveVideo': false,
    });
    
    // Apply bitrate constraints if possible (SDP manipulation is complex, 
    // but we can set parameters on senders after adding tracks)
    _peerConnection!.getSenders().forEach((sender) {
      if (sender.track?.kind == 'video') {
        var parameters = sender.parameters;
        parameters.encodings.forEach((encoding) {
          encoding.maxBitrate = _selectedBitrate * 1000;
        });
        sender.setParameters(parameters);
      }
    });

    await _peerConnection!.setLocalDescription(offer);

    socket.emit('signal', {
      'roomId': roomId,
      'data': {'type': 'offer', 'sdp': offer.sdp}
    });

    socket.on('signal', (data) async {
      if (data['data']['type'] == 'answer') {
        await _peerConnection!.setRemoteDescription(RTCSessionDescription(data['data']['sdp'], 'answer'));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Mahathi Live - Child")),
      body: GestureDetector(
        onTap: () {
          FlutterBackgroundService().invoke('user-activity');
        },
        behavior: HitTestBehavior.translucent,
        child: roomId == null
            ? Column(
              children: [
                Expanded(
                  child: MobileScanner(
                    onDetect: (capture) {
                      final List<Barcode> barcodes = capture.barcodes;
                      if (barcodes.isNotEmpty) {
                        setState(() => roomId = barcodes.first.rawValue);
                      }
                    },
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(16),
                  color: Colors.grey[200],
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Stream Quality Settings", style: TextStyle(fontWeight: FontWeight.bold)),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Resolution:"),
                          DropdownButton<String>(
                            value: _selectedResolution,
                            items: _resolutions.keys.map((res) => DropdownMenuItem(value: res, child: Text(res))).toList(),
                            onChanged: (val) => setState(() => _selectedResolution = val!),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("FPS:"),
                          DropdownButton<int>(
                            value: _selectedFPS,
                            items: [15, 30, 60].map((fps) => DropdownMenuItem(value: fps, child: Text("$fps FPS"))).toList(),
                            onChanged: (val) => setState(() => _selectedFPS = val!),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Bitrate:"),
                          DropdownButton<int>(
                            value: _selectedBitrate,
                            items: [500, 1000, 2000, 4000].map((br) => DropdownMenuItem(value: br, child: Text("${br} kbps"))).toList(),
                            onChanged: (val) => setState(() => _selectedBitrate = val!),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            )
          : Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Streaming to Room: $roomId", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text("Quality: $_selectedResolution @ $_selectedFPS FPS (${_selectedBitrate}kbps)", style: TextStyle(fontSize: 14, color: Colors.blueGrey)),
                  SizedBox(height: 10),
                  Text("Foreground Service Active", style: TextStyle(color: Colors.green)),
                  SizedBox(height: 30),
                  if (_localStream == null) // Show start button if not yet streaming
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15)),
                      onPressed: () => _startStreaming(roomId!),
                      child: Text("Start Streaming"),
                    )
                  else
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                      onPressed: () {
                        FlutterBackgroundService().invoke('stopService');
                        _peerConnection?.close();
                        _peerConnection = null;
                        _localStream?.getTracks().forEach((track) => track.stop());
                        _localStream = null;
                        setState(() {
                          roomId = null;
                        });
                      },
                      child: Text("Stop Monitoring"),
                    ),
                ],
              ),
            ),
      ),
    );
  }
}
